import pandas as pd
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.layers import Embedding, Conv1D, MaxPooling1D, Dense, GlobalAveragePooling1D,Dropout
from tensorflow.keras.preprocessing.sequence import pad_sequences

import numpy as np
import time	
##from numpy.random import seed
##seed(1)
##from tensorflow.python import set_random_seed
##set_random_seed(2)
from tensorflow.keras import Sequential, Model, Input
from tensorflow.keras.callbacks import ModelCheckpoint
start=time.asctime( time.localtime(time.time()) )
print("Load Text")


df = pd.read_csv('fake_news/train.csv',delimiter=',', encoding='utf8')
print("Initialization_parameters")
max_word_num=50000 #n
max_seq_length=1500#m
embedding_dim=300#k
print("Remove stop words")
stop_words = ENGLISH_STOP_WORDS
df['text']=df['text'].apply(lambda x: ' '.join([word for word in str(x).split() if word not in (stop_words)]))#remove stop words
df['text']=df['text'].apply(lambda x: ' '.join([word for word in str(x).split()]))
data = df['text'].values.tolist()
labels = df['label'].values.tolist()#0->real 1->fake
print("Tokenization")
tokenizer = Tokenizer(num_words=max_word_num, filters='!"#$%&()*+,-./:;<=>?@[\]^_`{|}~')#tokenization
#get num_words from text and gives each word an id
tokenizer.fit_on_texts(data)#tranforms each text to a sequence of word_ids
sequences = tokenizer.texts_to_sequences(data)#all sequences must have the same  number of words
word_index = tokenizer.word_index
print("Get samples of sentences from texts")
data = pad_sequences(sequences, maxlen=max_seq_length)
print("Dataset split")
#90% train, 5% validation,5% test
train_end=int(0.9*len(data))
test_end=int(0.95*len(data))
train_data = data[:train_end]
train_labels = labels[:train_end]
test_data = data[train_end:test_end]
test_labels = labels[train_end:test_end]
valid_data=data[test_end:]
valid_labels=labels[test_end:]

#Define  input layer that specifies the shape of input data
print("Input layer size specification")
input_data=Input(shape=(max_seq_length,), dtype='int32')

print("Read embedding file")
embeddingsfile='wordEmbeddings/glove.6B.300d.txt'
embeddings_index = {}
print("Scan and store  word coefs from file")
file = open(embeddingsfile, 'r', encoding='utf8')
for line in file:
    #here we parse the data from the file
    values = line.split(' ') #split the line by spaces
    word = values[0] #each line starts with the word
    coefs = np.asarray(values[1:], dtype='float32') #the rest of the line is the vector
    embeddings_index[word] = coefs #put into embedding dictionary
file.close()
#Create Embedding Matrix & Embedding Layer
print("Creating embedding matrix")
embedding_matrix = np.zeros((len(word_index) + 1, embedding_dim))
count=0
for word in word_index.items():
     embedding_vector = embeddings_index.get(word)
     #if word is in glove vocabulary  a embeding vector exist else zeros values
     if embedding_vector is not None:
          embedding_matrix[count] = embedding_vector

     count=count+1
#Design embedding layer  with size of vocabulary
print("Creating embedding layer")     
embedding_layer = Embedding(len(word_index) + 1,embedding_dim,weights=[embedding_matrix],input_length=max_seq_length,trainable=False)
#integrate embedding layer  into input of the model
print("Integration of embedding layer into input of the model")
embedded_data = embedding_layer(input_data)
#Convolutional Layer 1  with  window 5 and  output length 64  method activation relu
#activation method->function  use to get the output of node
print("Convolutional layer 1")
print("Convolution")
l1= Conv1D(64, 5, activation='relu')(embedded_data)
#Max pooling  apply max filter to non overlapping  subregion  of the initial represantation
# sample based discretization process ->downsample input represantation  reducing its dimensionality
#select the most representatives elements reduce computational cost less parameters
print("Maxpooling")
l1= MaxPooling1D(5)(l1)
#Convolutional Layer 2  with  window 3 and  output length 128  method activation relu
print("Convolutional layer 2")
print("Convolution")
l2 = Conv1D(128, 3, activation='relu')(l1)
print("Maxpooling")
#l2= MaxPooling1D(5)(l2)
l2= MaxPooling1D(3)(l2)
#Convolutional Layer 3  with  window 2 and  output length 256  method activation relu
print("Convolutional layer 3")
print("Convolution")
l3 = Conv1D(256, 2, activation='relu')(l2)
#Global pooling get   avg  of output elements
print("avgpooling")
l3 = GlobalAveragePooling1D()(l3)
#Create a Dense Neural Network Layer 1 with  2048 output nodes method activation relu
print("Dense layer 1")
d1 = Dense(2048, activation='relu')(l3)
#Dropout  of input l3 ->regularization technique during  updating  a  layer of neural network
#randomly  selection of nodes(half of them) tha don't update or dropout
#so probabilities change of node and no  change of node 0.5->net not depending on
#node  in the layer too much
#setting  with random way a fraction of input units to 0 at each update
#during training time, which helps prevent overfitting.
d1 = Dropout(0.8)(d1)
#Create a Dense Neural Network Layer 2 with  512 output nodes method activation relu
print("Dense layer 2")
d2 = Dense(512, activation='relu')(d1)
#init val for drop 0.5
d2 = Dropout(0.3)(d2)
#Output layer with 2 output nodes(one for real, one for fake) with softmax(activation method for multiclass)
print("Output layer")
out=Dense(2, activation='softmax')(d2)
#Put input and output specifications in model
print("Specification for input and output of model")
model = Model(input_data, out)
#Search for model parameters?
print("Define loss function->categorical_crossentropy, optimization method->Adamax,metrics->accuracy")
model.compile(loss='sparse_categorical_crossentropy',optimizer='adamax',metrics=['acc'])
print("Train Model with dataset")
model.fit(train_data, train_labels,validation_data=(valid_data, valid_labels),epochs=60, batch_size=4500,workers=4,
    use_multiprocessing=True,
)






model.evaluate(test_data, test_labels,workers=4,use_multiprocessing=True)
# Save the weights
model.save_weights('model_weights.h5')

# Save the model architecture
with open('model_architecture.json', 'w') as f:
    f.write(model.to_json())



end=time.asctime( time.localtime(time.time()) )
print(start)
print(end)







