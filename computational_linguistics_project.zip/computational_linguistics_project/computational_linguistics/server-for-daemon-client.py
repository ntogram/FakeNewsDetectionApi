import pandas as pd
from tensorflow.keras.preprocessing.text import Tokenizer
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from tensorflow.keras.models import model_from_json
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np
import newspaper
import pika
import psycopg2
from psycopg2 import Error

max_word_num=50000 # n
max_seq_length=1500 # m
stop_words = ENGLISH_STOP_WORDS
tokenizer = Tokenizer(num_words=max_word_num, filters='!"#$%&()*+,-./:;<=>?@[\]^_`{|}~')
with open('model_architecture.json', 'r') as f:
    model = model_from_json(f.read())
model.load_weights('model_weights.h5')

connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))

channel = connection.channel()
channel.queue_declare(queue='rpc_queue_server')

def insert(article, result):
    try:
        connection = psycopg2.connect(user = "postgres",
                                      password = "postgres",
                                      host = "127.0.0.1",
                                      port = "5432",
                                      database = "fakenews")
        cursor = connection.cursor()
        postgres_insert_query = """INSERT INTO newsdata(article_body, prediction, truth_ratio,fake_ratio) VALUES (%s,%s,%s,%s);"""
        if (result[0][0] >= result[0][1]):
            prediction = 0
        else:
            prediction = 1
        true = float(result[0][0])
        true = round(true, 8)
        false = float(result[0][1])
        false = round(false, 8)
        record_to_insert = (article, prediction, true, false)
        cursor.execute(postgres_insert_query, record_to_insert)
        connection.commit()
        count = cursor.rowcount
        #print (count, "Record inserted successfully into newsdata table")
        
        #cursor.execute(postgres_insert_query)
        #connection.commit()
        #print("Table created successfully in PostgreSQL ")
    except (Exception, psycopg2.DatabaseError) as error :
        print ("Error while creating PostgreSQL table", error)
    finally:
        if(connection):
            cursor.close()
            connection.close()
            #print("PostgreSQL connection is closed")

def analyze(n):
    data=[[n]]
    df=pd.DataFrame(data,columns=['text'])
    df['text']=df['text'].apply(lambda x: ' '.join([word for word in str(x).split() if word not in (stop_words)]))
    df['text']=df['text'].apply(lambda x: ' '.join([word for word in str(x).split()]))
    data = df['text'].values.tolist()
    tokenizer.fit_on_texts(data)
    sequences = tokenizer.texts_to_sequences(data)
    data = pad_sequences(sequences, maxlen=max_seq_length)
    result=model.predict(data)
    print(" [.]", result)
    insert(n[2:-1], result)
    if (result[0][0] >= result[0][1]):
        #print("Real")
        return 0
    else:
        #print("Fake")
        return 1

def on_request(ch, method, props, body):
    n = str(body)

    print(" [.] analyze(%s)" % n[2:-1])
    response = analyze(n)

    ch.basic_publish(exchange='',
                     routing_key=props.reply_to,
                     properties=pika.BasicProperties(correlation_id = \
                                                         props.correlation_id),
                     body=str(response))
    ch.basic_ack(delivery_tag=method.delivery_tag)

channel.basic_qos(prefetch_count=1)
channel.basic_consume(queue='rpc_queue_server', on_message_callback=on_request)

print(" [x] Awaiting RPC requests. To exit press CTRL+C")
channel.start_consuming()