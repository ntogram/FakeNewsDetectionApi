from tensorflow.keras.models import model_from_json
import pandas as pd
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
import numpy as np



with open('model_architecture.json', 'r') as f:
    model = model_from_json(f.read())
model.load_weights('model_weights.h5')
df = pd.read_csv('train.csv',delimiter=',', encoding='utf8')
print("Initialization_parameters")
max_word_num=50000 #n
max_seq_length=1500#m
embedding_dim=300#k
print("Remove stop words")
stop_words = ENGLISH_STOP_WORDS
df['text']=df['text'].apply(lambda x: ' '.join([word for word in str(x).split() if word not in (stop_words)]))#remove stop words
df['text']=df['text'].apply(lambda x: ' '.join([word for word in str(x).split()]))
data = df['text'].values.tolist()
labels = df['label'].values.tolist()#0->real 1->fake
print("Tokenization")
tokenizer = Tokenizer(num_words=max_word_num, filters='!"#$%&()*+,-./:;<=>?@[\]^_`{|}~')#tokenization
#get num_words from text and gives each word an id
tokenizer.fit_on_texts(data)#tranforms each text to a sequence of word_ids
sequences = tokenizer.texts_to_sequences(data)#all sequences must have the same  number of words
word_index = tokenizer.word_index
print("Get samples of sentences from texts")
data = pad_sequences(sequences, maxlen=max_seq_length)
print("Dataset split")
#90% train, 5% validation,5% test
train_end=int(0.9*len(data))
test_end=int(0.95*len(data))
train_data = data[:train_end]
train_labels = labels[:train_end]
test_data = data[train_end:test_end]
test_labels = labels[train_end:test_end]
valid_data=data[test_end:]
valid_labels=labels[test_end:]
predictions=[]
total_test_data=np.concatenate((test_data,valid_data),axis=0)
total_test_labels=test_labels+valid_labels
predictions=model.predict(total_test_data)
pred_class=[]
for item in predictions:
    if (item[0] >= item[1]):
       pred_class.append(0)
       
    else:
         pred_class.append(1)
        
# accuracy: (tp + tn) / (p + n)
accuracy = accuracy_score(total_test_labels, pred_class)
print('Accuracy: %f' % accuracy)
# precision tp / (tp + fp)
precision = precision_score(total_test_labels, pred_class)
print('Precision: %f' % precision)
# recall: tp / (tp + fn)
recall = recall_score(total_test_labels, pred_class)
print('Recall: %f' % recall)
# f1: 2 tp / (2 tp + fp + fn)
f1 = f1_score(total_test_labels, pred_class)
print('F1 score: %f' % f1)
