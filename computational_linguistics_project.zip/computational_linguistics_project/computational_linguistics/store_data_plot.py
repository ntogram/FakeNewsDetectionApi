import psycopg2
from psycopg2 import Error
import numpy as np
import matplotlib.pyplot as plt
try:
    connection = psycopg2.connect(user = "postgres",
                                  password = "postgres",
                                  host = "127.0.0.1",
                                  port = "5432",
                                  database = "fakenews")
    cursor = connection.cursor()
    postgreSQL_select_Query = "select prediction,fake_ratio from newsdata"
    cursor.execute(postgreSQL_select_Query)
    fake_data=cursor.fetchall()
   
    print("Query executed successfully in PostgreSQL ")
    connection.commit()
##    print("Table created successfully in PostgreSQL ")
except (Exception, psycopg2.DatabaseError) as error :
    print ("Error while creating PostgreSQL table", error)
finally:
    #closing database connection.
        if(connection):
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")


print("Plot Histograms")
predlist=[]
ratiolist=[]
for row in fake_data:
    predlist.append(row[0])
    ratiolist.append(row[1])


bins1=2
bins2=5
arr=np.array(predlist)
weights1 = np.ones_like(predlist)/float(len(predlist))
labels, counts = np.unique(arr, return_counts=True)
plt.figure()
pn, pbins, ppatches = plt.hist(predlist, bins1, facecolor='blue', alpha=0.5,rwidth=0.5,weights=weights1)
plt.xticks([])
plt.bar(labels, pn, align='center')
plt.gca().set_xticks(labels)
plt.yticks(np.arange(0, 1.2, step=0.2))
plt.title(r'Prediction Histogram')
plt.gca().set_xlabel('Type of news')
plt.gca().set_ylabel('Fraction of articles')
plt.show(block=False)
range = (0, 1)
bins=5
weights2 = np.ones_like(ratiolist)/float(len(ratiolist))
plt.figure()
n, rbins, rpatches = plt.hist(ratiolist, bins2, facecolor='green', alpha=0.5,histtype='bar', ec='black',edgecolor='k',linewidth=3,weights=weights2)
plt.yticks(np.arange(0, 1.2, step=0.2))
plt.xticks(np.arange(0, 1.2, step=0.2))
plt.title(r'Fake Ratio Histogram')
plt.gca().set_xlabel('Fake Ratio')
plt.gca().set_ylabel('Fraction of articles')
plt.show()
