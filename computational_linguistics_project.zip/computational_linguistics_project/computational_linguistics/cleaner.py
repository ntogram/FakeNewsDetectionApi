import psycopg2
from psycopg2 import Error

try:
	connection = psycopg2.connect(user = "postgres",
                                  password = "postgres",
                                  host = "127.0.0.1",
                                  port = "5432",
                                  database = "fakenews")
	cursor = connection.cursor()
	postgreSQL_select_Query = "select count(*) from newsdata"
	cursor.execute(postgreSQL_select_Query)
	fake_data=cursor.fetchall()
	if (fake_data[0][0] > 10000):
		postgreSQL_delete_Query = "delete from newsdata"
		cursor.execute(postgreSQL_delete_Query)
	connection.commit()
except (Exception, psycopg2.DatabaseError) as error :
    print ("Error while creating PostgreSQL table", error)
finally:
        if(connection):
            cursor.close()
            connection.close()