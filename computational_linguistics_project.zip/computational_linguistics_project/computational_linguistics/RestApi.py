import client_rest
import client_rest_batch
import client_rest_page
from flask import Flask, jsonify, request
import json

app = Flask(__name__)

@app.route('/', methods = ['GET', 'POST'])
def index():
	if (request.method == 'POST'):
		some_json = request.get_json()
		client = client_rest.RpcClient()
		response = client.call(some_json["article"])
		response = response[2:-1]
		response = json.loads(response)
		return jsonify(response), 200
	if (request.method == 'GET'):
		return jsonify({"article":"replace this with your article"})

@app.route('/batch', methods = ['GET', 'POST'])
def batch():
	if (request.method == 'POST'):
		some_json = request.get_json()
		client = client_rest_batch.RpcClient()
		response = client.call(json.dumps(some_json))
		response = response[2:-1]
		response = json.loads(response)
		return jsonify(response), 200
	if (request.method == 'GET'):
		return jsonify({"articles":["article1","article2"]})

@app.route('/page', methods = ['GET', 'POST'])
def fromPage():
	if (request.method == 'POST'):
		some_json = request.get_json()
		client = client_rest_page.RpcClient()
		response = client.downloadArticles(some_json["url"], some_json["num"])
		response = response[2:-1]
		response = json.loads(response)
		return jsonify(response)
	if (request.method == 'GET'):
		return jsonify({"url":"replace this with a url", "num":"number of articles (must be integer)"})
if __name__ == '__main__':
	app.run()