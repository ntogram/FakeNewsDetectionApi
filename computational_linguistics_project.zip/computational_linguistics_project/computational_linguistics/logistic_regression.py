from sklearn.linear_model import LogisticRegression
import pandas as pd
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from numbers import Number

tf = pd.read_csv('train.csv',delimiter=',', encoding='utf8')
tf["text"]=tf["text"].str.lower()
stop_words = ENGLISH_STOP_WORDS
tf["text"]=tf["text"].apply(lambda x: ' '.join([word for word in str(x).split() if word not in (stop_words)]))
print("Calculate features digrams")
tfidf_vectorizer = TfidfVectorizer(ngram_range=(1, 1))
features =tfidf_vectorizer.fit_transform(tf["text"])
print("K-Fold Cross Validation")
kf = KFold(n_splits=10)
kf.get_n_splits(features)
y=tf['label']
print("Create Logistic Regression")
model = LogisticRegression()
accuracy=0
precision=0
recall=0
f_measure=0
for train_index, test_index in kf.split(features):
    X_train, X_test = features[train_index], features[test_index]
    y_train, y_test = y[train_index], y[test_index]
    print("Start  Logistic Regression")
    model.fit(X_train, y_train)
    print("Start Logistic Regression predicting")
    y_pred = model.predict(X_test)
    accuracy=accuracy+accuracy_score(y_test, y_pred)
    precision=precision+precision_score(y_test, y_pred,average='macro')
    recall=recall+recall_score(y_test, y_pred,average='macro')
    f_measure=f_measure+f1_score(y_test, y_pred,average='macro')

precision=float(precision/(10.0))
accuracy=float(accuracy/(10.0))
recall=float(recall/(10.0))
f_measure=float(f_measure/(10.0))
print("accuracy: "+str(accuracy))
print("precision: "+str(precision))
print("recall: "+str(recall))
print("f-measure: "+str(f_measure))
