# import pandas as pd
# from tensorflow.keras.preprocessing.text import Tokenizer
# from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
# from tensorflow.keras.models import model_from_json
# from tensorflow.keras.preprocessing.sequence import pad_sequences
# import numpy as np
import newspaper
import pika
import uuid
import json

class RpcClient(object):
    def __init__(self):
        self.connection = pika.BlockingConnection(
            pika.ConnectionParameters(host='localhost'))

        self.channel = self.connection.channel()

        result = self.channel.queue_declare('', exclusive=True)
        self.callback_queue = result.method.queue

        self.channel.basic_consume(
            queue=self.callback_queue,
            on_message_callback=self.on_response,
            auto_ack=True)

    def on_response(self, ch, method, props, body):
        if self.corr_id == props.correlation_id:
            self.response = body

    # def call(self, n):
    #     self.response = None
    #     self.corr_id = str(uuid.uuid4())
    #     self.channel.basic_publish(
    #         exchange='',
    #         routing_key='rpc_queue_server_rest_page',
    #         properties=pika.BasicProperties(
    #             reply_to=self.callback_queue,
    #             correlation_id=self.corr_id,
    #         ),
    #         body=str(n))
    #     while self.response is None:
    #         self.connection.process_data_events()
    #     return int(self.response)

    def downloadArticles(self, url, num):
        item = {"url": url, "num": num}
        #print(item)
        self.response = None
        self.corr_id = str(uuid.uuid4())
        self.channel.basic_publish(
            exchange='',
            routing_key='rpc_queue_server_rest_page',
            properties=pika.BasicProperties(
                reply_to=self.callback_queue,
                correlation_id=self.corr_id,
            ),
            body=str(json.dumps(item)))
        while self.response is None:
            self.connection.process_data_events()
        return str(self.response)