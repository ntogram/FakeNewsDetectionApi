import pandas as pd
from tensorflow.keras.preprocessing.text import Tokenizer
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from tensorflow.keras.models import model_from_json
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np
import newspaper
import psycopg2
from psycopg2 import Error
import sys
import matplotlib.pyplot as plt
non_bmp_map = dict.fromkeys(range(0x10000, sys.maxunicode + 1), 0xfffd)
##df = pd.read_csv('train.csv',delimiter=',', encoding='utf8')
print("Initialization_parameters")
max_word_num=50000 #n
max_seq_length=1500#m
embedding_dim=300#k
stop_words = ENGLISH_STOP_WORDS
df = pd.read_csv('train_set.csv',delimiter='\t')
df["Content"]=df["Content"].apply(lambda x: x.lower())
stop_words = ENGLISH_STOP_WORDS
df["Content"]=df["Content"].apply(lambda x: ' '.join([word for word in x.split() if word not in (stop_words)]))
df['Content']=df['Content'].apply(lambda x: ' '.join([word for word in str(x).split()]))


#df=df.loc[df['Category'] == 'Politics']
#df=df.loc[df['Category'] == 'Business']
#df=df.loc[df['Category'] == 'Football']
#df=df.loc[df['Category'] == 'Film']
df=df.loc[df['Category'] == 'Technology']
##df=df[0:100]
##df['Content']=tf['Content']
print("Tokenizer Implementation")
tokenizer = Tokenizer(num_words=max_word_num, filters='!"#$%&()*+,-./:;<=>?@[\]^_`{|}~')
predictions=[]
true_ratios=[]
false_ratios=[]
true_ratio=0.0
false_ratio=0.0
print("Load Model")
with open('model_architecture.json', 'r') as f:
    model = model_from_json(f.read())
model.load_weights('model_weights.h5')
count=df['Content'].count()
for i in range(count):
    print("Article" + str(i))
    data = df['Content'][i:i+1]
    print("Tokenization")
    tokenizer.fit_on_texts(data)
    sequences = tokenizer.texts_to_sequences(data)
    data = pad_sequences(sequences, maxlen=max_seq_length)
    result=model.predict(data)
    print(result)
    true_ratio=float(result[0][0])
    true_ratio=round(true_ratio,8)
    true_ratios.append(true_ratio)
    false_ratio=float(result[0][1])
    false_ratio=round(false_ratio,8)
    false_ratios.append(false_ratio)
    if (result[0][0] >= result[0][1]):
       predictions.append(0)
       
    else:
         predictions.append(1)
        




    
    print("\n \n ")
    
data = df['Content'].values.tolist()
try:
    connection = psycopg2.connect(user = "postgres",
                                  password = "postgres",
                                  host = "127.0.0.1",
                                  port = "5432",
                                  database = "fakenews")
    cursor = connection.cursor()
    
    for i in  range(1,count):
           postgres_insert_query = """INSERT INTO newsdata(article_body, prediction, truth_ratio,fake_ratio) VALUES (%s,%s,%s,%s);"""
           record_to_insert = (data[i],predictions[i] , true_ratios[i],false_ratios[i])
           cursor.execute(postgres_insert_query, record_to_insert)
           connection.commit()
           count = cursor.rowcount
           print (count, "Record inserted successfully into newsdata table")


    connection.commit()

except (Exception, psycopg2.DatabaseError) as error :
    print ("Error while creating PostgreSQL table", error)
finally:
    #closing database connection.
        if(connection):
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")




