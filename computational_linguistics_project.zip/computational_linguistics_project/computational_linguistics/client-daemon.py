# import pandas as pd
# from tensorflow.keras.preprocessing.text import Tokenizer
# from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
# from tensorflow.keras.models import model_from_json
# from tensorflow.keras.preprocessing.sequence import pad_sequences
# import numpy as np
import newspaper
import pika
import uuid

class RpcClient(object):
    def __init__(self):
        self.connection = pika.BlockingConnection(
            pika.ConnectionParameters(host='localhost'))

        self.channel = self.connection.channel()

        result = self.channel.queue_declare('', exclusive=True)
        self.callback_queue = result.method.queue

        self.channel.basic_consume(
            queue=self.callback_queue,
            on_message_callback=self.on_response,
            auto_ack=True)

    def on_response(self, ch, method, props, body):
        if self.corr_id == props.correlation_id:
            self.response = body

    def call(self, n):
        self.response = None
        self.corr_id = str(uuid.uuid4())
        self.channel.basic_publish(
            exchange='',
            routing_key='rpc_queue_server',
            properties=pika.BasicProperties(
                reply_to=self.callback_queue,
                correlation_id=self.corr_id,
            ),
            body=str(n))
        while self.response is None:
            self.connection.process_data_events()
        return int(self.response)

cnn_paper = newspaper.build('https://edition.cnn.com/', memoize_articles=False)
articles=[]
articles_no = 3
count=0
for article in cnn_paper.articles:
    if(count<articles_no):
        article.download()
        article.parse()
        articles.append(article.text) 
    else:
        break
    count=count+1

n = 0 # send the article in position n
file = open("client-daemon-file.txt", "r")
content = file.read()
file.close()
if (content != articles[n]):
    file = open("client-daemon-file.txt", "w")
    file.write(articles[n])
    file.close()
    tmp_client = RpcClient()
    print(" [.] analyze(", articles[n], ")")
    response = tmp_client.call(articles[n])
    if (response == 0):
        print(" [.] Prediction: Real")
    if (response == 1):
        print(" [.] Prediction: Fake")