import pandas as pd
from tensorflow.keras.preprocessing.text import Tokenizer
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from tensorflow.keras.models import model_from_json
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np
import newspaper
import psycopg2
from psycopg2 import Error
import sys
import matplotlib.pyplot as plt
non_bmp_map = dict.fromkeys(range(0x10000, sys.maxunicode + 1), 0xfffd)
##df = pd.read_csv('train.csv',delimiter=',', encoding='utf8')
print("Initialization_parameters")
max_word_num=50000 #n
max_seq_length=1500#m
embedding_dim=300#k
stop_words = ENGLISH_STOP_WORDS




##cnn_paper = newspaper.build('https://bients.com/', memoize_articles=False)
cnn_paper = newspaper.build('https://edition.cnn.com/', memoize_articles=False)
#cnn_paper = newspaper.build('https://www.thegatewaypundit.com/', memoize_articles=False)
articles=[]
articles_no =int( input ("Enter number: "))
if(articles_no>len(cnn_paper.articles)):
    articles_no=len(cnn_paper.articles)
##articles_no=1
count=0
for article in cnn_paper.articles:
##    print("here")
    if(count<articles_no):
        try:
            print(count)
            article.download()
            article.parse()
            articles.append(article.text)
            count=count+1
        except:
          pass
       
    else:
        break
    
count=1
print("Tokenizer Implementation")
tokenizer = Tokenizer(num_words=max_word_num, filters='!"#$%&()*+,-./:;<=>?@[\]^_`{|}~')
predictions=[]
true_ratios=[]
false_ratios=[]
true_ratio=0.0
false_ratio=0.0
print("Load Model")
with open('model_architecture.json', 'r') as f:
    model = model_from_json(f.read())
model.load_weights('model_weights.h5')

for current_article in articles:
    print("Article" + str(count))
    print(str(current_article).translate(non_bmp_map))
    print("Format Preprocess")
    data=[[current_article]]
    df=pd.DataFrame(data,columns=['text'])
    df['text']=df['text'].apply(lambda x: ' '.join([word for word in str(x).split() if word not in (stop_words)]))
    df['text']=df['text'].apply(lambda x: ' '.join([word for word in str(x).split()]))
    data = df['text'].values.tolist()
    print("Tokenization")
    tokenizer.fit_on_texts(data)
    sequences = tokenizer.texts_to_sequences(data)
    data = pad_sequences(sequences, maxlen=max_seq_length)
    result=model.predict(data)
    print(result)
    true_ratio=float(result[0][0])
    true_ratio=round(true_ratio,8)
    true_ratios.append(true_ratio)
    false_ratio=float(result[0][1])
    false_ratio=round(false_ratio,8)
    false_ratios.append(false_ratio)
    if (result[0][0] >= result[0][1]):
       predictions.append(0)
       
    else:
         predictions.append(1)
        




    
    print("\n \n ")
    count=count+1
try:
    connection = psycopg2.connect(user = "postgres",
                                  password = "postgres",
                                  host = "127.0.0.1",
                                  port = "5432",
                                  database = "fakenews")
    cursor = connection.cursor()
    
    for i in  range(len(articles)):
           postgres_insert_query = """INSERT INTO newsdata(article_body, prediction, truth_ratio,fake_ratio) VALUES (%s,%s,%s,%s);"""
           record_to_insert = (articles[i],predictions[i] , true_ratios[i],false_ratios[i])
           cursor.execute(postgres_insert_query, record_to_insert)
           connection.commit()
           count = cursor.rowcount
           print (count, "Record inserted successfully into newsdata table")
##   postgreSQL_select_Query = "select prediction,fake_ratio from newsdata"
##    cursor.execute(postgreSQL_select_Query)
##    fake_data=cursor.fetchall()
##   

    connection.commit()

except (Exception, psycopg2.DatabaseError) as error :
    print ("Error while creating PostgreSQL table", error)
finally:
    #closing database connection.
        if(connection):
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")



##predlist=[]
##ratiolist=[]
##for row in fake_data:
##    predlist.append(row[0])
##    ratiolist.append(row[1])
##
##
##bins1=2
##bins2=5
##arr=np.array(predlist)
##weights1 = np.ones_like(predlist)/float(len(predlist))
##labels, counts = np.unique(arr, return_counts=True)
##plt.figure()
##pn, pbins, ppatches = plt.hist(predlist, bins1, facecolor='blue', alpha=0.5,rwidth=0.5,weights=weights1)
##plt.xticks([])
##plt.bar(labels, pn, align='center')
##plt.gca().set_xticks(labels)
##plt.yticks(np.arange(0, 1.2, step=0.2))
##plt.title(r'Prediction Histogram')
##plt.gca().set_xlabel('Type of news')
##plt.gca().set_ylabel('Fraction of articles')
##plt.show(block=False)
##range = (0, 1)
##bins=5
##weights2 = np.ones_like(ratiolist)/float(len(ratiolist))
##plt.figure()
##n, rbins, rpatches = plt.hist(ratiolist, bins2, facecolor='green', alpha=0.5,histtype='bar', ec='black',edgecolor='k',linewidth=3,weights=weights2)
##plt.yticks(np.arange(0, 1.2, step=0.2))
##plt.title(r'Fake Ratio Histogram')
##plt.gca().set_xlabel('Fake Ratio')
##plt.gca().set_ylabel('Fraction of articles')
##plt.show(block=False)
##






